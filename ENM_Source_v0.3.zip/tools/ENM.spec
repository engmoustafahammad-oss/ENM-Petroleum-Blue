# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

ROOT = Path(SPECPATH).parent
hiddenimports = collect_submodules('enm')
for package in ('PySide6', 'cryptography', 'paramiko', 'pysnmp', 'sqlcipher3'):
    try:
        hiddenimports += collect_submodules(package)
    except Exception:
        pass

datas = []
for package in ('PySide6', 'pysnmp'):
    try:
        datas += collect_data_files(package)
    except Exception:
        pass
if (ROOT / 'resources').exists():
    datas.append((str(ROOT / 'resources'), 'resources'))

analysis = Analysis(
    [str(ROOT / 'enm' / '__main__.py')],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(analysis.pure)
exe = EXE(
    pyz,
    analysis.scripts,
    analysis.binaries,
    analysis.datas,
    [],
    name='ENM',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    icon=str(ROOT / 'resources' / 'enm_logo.ico') if (ROOT / 'resources' / 'enm_logo.ico').exists() else None,
)
