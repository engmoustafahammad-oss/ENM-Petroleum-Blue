# ENM — Enterprise Network Manager

**Petroleum Blue Edition** — published by Sunrise Systems for enterprise network management.

This repository contains the Windows desktop product source, the separate Owner License Manager, security documentation, test records, and packaging scripts.

## Current build status

This is the first engineering baseline. It establishes the central data model, secure services, offline licensing workflow, and a desktop shell. Network-hardware validation and Windows installer execution must be performed on a Windows test machine connected to an approved lab network.

## Run from source

```powershell
py -3 -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
python -m enm
```

The local database is created at `%LOCALAPPDATA%\\ENM\\enm.db` on Windows. The development fallback uses SQLite when SQLCipher is unavailable; production packaging must include SQLCipher and fail closed if encrypted storage cannot be initialized.

## Product applications

- `python -m enm` — engineer application.
- `python -m owner_license_manager` — owner-only license issuer.
- `tools/build_windows.ps1` — Windows build and installer pipeline.

## Security note

The repository does not contain a production private license-signing key. The owner manager creates and protects that key using Windows DPAPI on first secure initialization.
