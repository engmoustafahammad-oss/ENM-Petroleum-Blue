from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

APP_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local")) / "ENM"
DB_PATH = APP_DIR / "enm.db"

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL);
INSERT INTO schema_version(version) SELECT 1 WHERE NOT EXISTS (SELECT 1 FROM schema_version);
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('administrator','network_engineer','read_only')),
    enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS locations (
    id INTEGER PRIMARY KEY, parent_id INTEGER REFERENCES locations(id) ON DELETE RESTRICT,
    kind TEXT NOT NULL CHECK(kind IN ('site','building','room','rack','control_room')),
    name TEXT NOT NULL, code TEXT, description TEXT, UNIQUE(parent_id, name)
);
CREATE TABLE IF NOT EXISTS devices (
    id INTEGER PRIMARY KEY, location_id INTEGER REFERENCES locations(id) ON DELETE SET NULL,
    name TEXT NOT NULL UNIQUE, hostname TEXT, ip_address TEXT, mac_address TEXT,
    serial_number TEXT, vendor TEXT, model TEXT, device_type TEXT NOT NULL,
    os_name TEXT, firmware_version TEXT, status TEXT NOT NULL DEFAULT 'unknown',
    snmp_profile_id INTEGER, ssh_profile_id INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
    CREATE TABLE IF NOT EXISTS credentials (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, scope TEXT NOT NULL,
    encrypted_payload BLOB NOT NULL, nonce BLOB NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS snmp_profiles (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, version TEXT NOT NULL CHECK(version IN ('1','2c','3')),
    port INTEGER NOT NULL DEFAULT 161, security_level TEXT, auth_protocol TEXT, privacy_protocol TEXT,
    credential_id INTEGER REFERENCES credentials(id) ON DELETE SET NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ssh_profiles (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, port INTEGER NOT NULL DEFAULT 22,
    credential_id INTEGER REFERENCES credentials(id) ON DELETE SET NULL, vendor_os TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ssh_sessions (
    id INTEGER PRIMARY KEY, device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, state TEXT NOT NULL DEFAULT 'closed',
    started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, ended_at TEXT
);
CREATE TABLE IF NOT EXISTS command_history (
    id INTEGER PRIMARY KEY, session_id INTEGER NOT NULL REFERENCES ssh_sessions(id) ON DELETE CASCADE,
    command TEXT NOT NULL, classification TEXT NOT NULL, executed INTEGER NOT NULL DEFAULT 0,
    output_redacted TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS device_credentials (
    device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    credential_id INTEGER NOT NULL REFERENCES credentials(id) ON DELETE CASCADE,
    PRIMARY KEY(device_id, credential_id)
);
CREATE TABLE IF NOT EXISTS ipam_records (
    id INTEGER PRIMARY KEY, device_id INTEGER REFERENCES devices(id) ON DELETE SET NULL,
    address TEXT NOT NULL UNIQUE, prefix INTEGER NOT NULL, vlan_id INTEGER, state TEXT NOT NULL DEFAULT 'allocated', note TEXT
);
CREATE TABLE IF NOT EXISTS vlans (
    id INTEGER PRIMARY KEY, vlan_id INTEGER NOT NULL UNIQUE, name TEXT NOT NULL, site_id INTEGER REFERENCES locations(id), description TEXT
);
CREATE TABLE IF NOT EXISTS device_links (
    source_device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    target_device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    source_port TEXT, target_port TEXT, link_type TEXT NOT NULL DEFAULT 'physical',
    PRIMARY KEY(source_device_id, target_device_id, source_port, target_port)
);
CREATE TABLE IF NOT EXISTS metrics (
    id INTEGER PRIMARY KEY, device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    metric_name TEXT NOT NULL, value REAL NOT NULL, collected_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY, device_id INTEGER REFERENCES devices(id) ON DELETE SET NULL,
    severity TEXT NOT NULL, title TEXT NOT NULL, details TEXT, state TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, resolved_at TEXT
);
CREATE TABLE IF NOT EXISTS configuration_revisions (
    id INTEGER PRIMARY KEY, device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    revision INTEGER NOT NULL, content_encrypted BLOB NOT NULL, nonce BLOB NOT NULL,
    user_id INTEGER REFERENCES users(id), description TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(device_id, revision)
);
CREATE TABLE IF NOT EXISTS audit_events (
    id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT, outcome TEXT NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS licenses (
    id INTEGER PRIMARY KEY, license_id TEXT NOT NULL UNIQUE, customer TEXT NOT NULL,
    engineer TEXT, issued_at TEXT NOT NULL, activated_at TEXT, expires_at TEXT,
    status TEXT NOT NULL DEFAULT 'issued', fingerprint TEXT, user_sid TEXT
);
CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


class Database:
    def __init__(self, path: Path | str = DB_PATH):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _initialize(self) -> None:
        conn = self._connect()
        try:
            conn.executescript(SCHEMA)
            self._migrate_legacy_schema(conn)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_devices_serial ON devices(serial_number)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_devices_ip ON devices(ip_address)")
            conn.execute("UPDATE schema_version SET version = MAX(version, 2)")
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def _migrate_legacy_schema(conn: sqlite3.Connection) -> None:
        """Bring databases created by older ENM builds up to the current schema.

        ``CREATE TABLE IF NOT EXISTS`` does not add columns to an existing
        SQLite table.  The first Windows bundles therefore failed when an
        older ``enm.db`` did not yet contain ``serial_number``.  Add only
        missing, non-destructive columns so existing inventory is preserved.
        """
        required_tables = {
            "devices": {
            "location_id": "INTEGER",
            "hostname": "TEXT",
            "ip_address": "TEXT",
            "mac_address": "TEXT",
            "serial_number": "TEXT",
            "vendor": "TEXT",
            "model": "TEXT",
            "os_name": "TEXT",
            "firmware_version": "TEXT",
            "status": "TEXT NOT NULL DEFAULT 'unknown'",
            "snmp_profile_id": "INTEGER",
            "ssh_profile_id": "INTEGER",
            # SQLite does not allow ALTER TABLE ... ADD COLUMN with a
            # non-constant CURRENT_TIMESTAMP default.  These are added as
            # nullable TEXT columns and backfilled immediately below.
            "created_at": "TEXT",
            "updated_at": "TEXT",
            },
            "alerts": {
                "device_id": "INTEGER",
                "severity": "TEXT NOT NULL DEFAULT 'warning'",
                "title": "TEXT NOT NULL DEFAULT 'Alert'",
                "details": "TEXT",
                "state": "TEXT NOT NULL DEFAULT 'open'",
                "created_at": "TEXT",
                "resolved_at": "TEXT",
            },
            "configuration_revisions": {
                "device_id": "INTEGER",
                "revision": "INTEGER NOT NULL DEFAULT 1",
                "content_encrypted": "BLOB",
                "nonce": "BLOB",
                "user_id": "INTEGER",
                "description": "TEXT",
                "created_at": "TEXT",
            },
            "audit_events": {
                "user_id": "INTEGER",
                "action": "TEXT NOT NULL DEFAULT 'legacy'",
                "entity_type": "TEXT NOT NULL DEFAULT 'system'",
                "entity_id": "TEXT",
                "outcome": "TEXT NOT NULL DEFAULT 'success'",
                "metadata_json": "TEXT NOT NULL DEFAULT '{}'",
                "created_at": "TEXT",
            },
            "app_settings": {
                "value": "TEXT NOT NULL DEFAULT ''",
            },
            "metrics": {
                "device_id": "INTEGER",
                "metric_name": "TEXT NOT NULL DEFAULT 'unknown'",
                "value": "REAL NOT NULL DEFAULT 0",
                "collected_at": "TEXT",
            },
        }
        timestamp_columns = {"created_at", "updated_at", "resolved_at", "collected_at"}
        for table, required_columns in required_tables.items():
            existing = {
                row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()
            }
            for column, definition in required_columns.items():
                if column not in existing:
                    # SQLite permits only constant defaults in ADD COLUMN.
                    # Timestamp fields are therefore nullable and backfilled.
                    safe_definition = "TEXT" if column in timestamp_columns else definition
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {safe_definition}")
                    if column in timestamp_columns and column != "resolved_at":
                        conn.execute(
                            f"UPDATE {table} SET {column}=CURRENT_TIMESTAMP WHERE {column} IS NULL"
                        )

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def execute(self, sql: str, params: tuple = ()) -> int:
        with self.transaction() as conn:
            cur = conn.execute(sql, params)
            return int(cur.lastrowid or 0)

    def fetch_all(self, sql: str, params: tuple = ()) -> list[dict]:
        conn = self._connect()
        try:
            return [dict(row) for row in conn.execute(sql, params).fetchall()]
        finally:
            conn.close()

    def fetch_one(self, sql: str, params: tuple = ()) -> dict | None:
        conn = self._connect()
        try:
            row = conn.execute(sql, params).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()
