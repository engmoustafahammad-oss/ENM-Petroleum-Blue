# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

ROOT = Path(SPECPATH).parent
hiddenimports = collect_submodules('enm')
for package in ('PySide6', 'cryptography', 'paramiko', 'pysnmp', 'sqlcipher3'):
    try:
        hiddenimports += collect_submodules(package)
    except Exception:
        pass

datas = []
for package in ('PySide6', 'pysnmp'):
    try:
        datas += collect_data_files(package)
    except Exception:
        pass
if (ROOT / 'resources').exists():
    datas.append((str(ROOT / 'resources'), 'resources'))

def make_app(script, name, icon=None):
    analysis = Analysis(
        [str(ROOT / script)], pathex=[str(ROOT)], binaries=[], datas=datas,
        hiddenimports=hiddenimports, hookspath=[], hooksconfig={}, runtime_hooks=[],
        excludes=[], noarchive=False,
    )
    pyz = PYZ(analysis.pure)
	return EXE(
	    pyz, analysis.scripts, analysis.binaries, analysis.datas, [], name=name,
	    debug=False, bootloader_ignore_signals=False, strip=False, upx=True,
	    console=False, icon=str(ROOT / icon) if icon and (ROOT / icon).exists() else None,
	    version=str(ROOT / 'tools' / 'version_info.txt'),
	)

app = make_app('enm/__main__.py', 'ENM', 'resources/enm_logo.ico')
license_app = make_app('owner_license_manager/__main__.py', 'ENM-Owner-License-Manager', 'resources/enm_logo.ico')
