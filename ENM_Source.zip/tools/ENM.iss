#define AppName "Enterprise Network Manager"
#define AppVersion "0.2.0"
#define Publisher "Mostafa Hammad"
#define AppExeName "ENM.exe"
#define LicenseExeName "ENM-Owner-License-Manager.exe"

[Setup]
AppId={{2F72F7D7-6E7B-4A1D-9B40-000000000001}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#Publisher}
DefaultDirName={autopf}\ENM
DefaultGroupName=ENM
OutputDir=..\release
OutputBaseFilename=ENM_Setup_v{#AppVersion}
SetupIconFile=..\enm\resources\enm.ico
UninstallDisplayIcon={app}\{#AppExeName}
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin

[Files]
Source: "..\dist\ENM\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion
Source: "..\dist\ENM-Owner-License-Manager\*"; DestDir: "{app}\OwnerLicenseManager"; Flags: recursesubdirs ignoreversion
Source: "..\enm\resources\enm.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\ENM"; Filename: "{app}\{#AppExeName}"; IconFilename: "{app}\enm.ico"
Name: "{commondesktop}\ENM"; Filename: "{app}\{#AppExeName}"; IconFilename: "{app}\enm.ico"
Name: "{group}\ENM Owner License Manager"; Filename: "{app}\OwnerLicenseManager\{#LicenseExeName}"; IconFilename: "{app}\enm.ico"

[Dirs]
Name: "{localappdata}\ENM"

[UninstallDelete]
Type: filesandordirs; Name: "{app}"
; User database under %LOCALAPPDATA%\ENM is intentionally preserved during uninstall.
