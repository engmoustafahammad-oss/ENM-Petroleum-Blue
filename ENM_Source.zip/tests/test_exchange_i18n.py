from pathlib import Path
from tempfile import TemporaryDirectory
from enm.core.db import Database
from enm.core.security import hash_password
from enm.core.services import SessionUser
from enm.core.exchange import ExchangeService
from enm.core.i18n import Translator


def test_exchange_and_i18n():
    with TemporaryDirectory() as d:
        db=Database(Path(d)/"enm.db"); uid=db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",("eng",hash_password("p"),"network_engineer")); user=SessionUser(uid,"eng","network_engineer"); db.execute("INSERT INTO devices(name,ip_address,device_type) VALUES(?,?,?)",("core","10.0.0.1","switch")); service=ExchangeService(db); out=Path(d)/"devices.json"; service.export_devices(out); assert 'core' in out.read_text(); inp=Path(d)/"in.json"; inp.write_text('[{"name":"new","ip_address":"10.0.0.2","device_type":"router"},{"name":"bad","ip_address":"nope"}]'); assert service.import_devices(user,inp)["inserted"] == 1
    ar=Translator("ar"); assert ar.rtl and ar.t("dashboard") == "لوحة المعلومات"; ar.set_language("en"); assert ar.t("dashboard") == "Dashboard"
