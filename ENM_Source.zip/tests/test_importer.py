from pathlib import Path
from tempfile import TemporaryDirectory
from enm.core.importers import parse_mobaxterm, deduplicate, export_preview_csv
from enm.core.db import Database
from enm.core.audit import AuditLog


def test_mobaxterm_import_preview():
    sample = """[Bookmarks]\nSubRep=KPC\\AG\nAG-Core-SW=#109#0%10.11.102.1%22%[User]%%\nAG-Core-SW-duplicate=#109#0%10.11.102.1%22%[User]%%\n"""
    with TemporaryDirectory() as d:
        p = Path(d) / "sessions.mxtsessions"; p.write_text(sample)
        sessions = deduplicate(parse_mobaxterm(p))
        assert len(sessions) == 2
        assert sessions[0].group == "KPC\\AG"
        assert sessions[0].host == "10.11.102.1"


def test_audit_filters_secrets():
    with TemporaryDirectory() as d:
        db = Database(Path(d) / "enm.db"); AuditLog(db).record("import", "device", 1, "success", metadata={"source":"mxtsessions", "password":"redacted"})
        row = db.fetch_one("SELECT metadata_json FROM audit_events")
        assert "password" not in row["metadata_json"]
