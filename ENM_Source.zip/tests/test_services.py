from pathlib import Path
from tempfile import TemporaryDirectory
import pytest
from enm.core.db import Database
from enm.core.security import hash_password
from enm.core.services import AuthService, DeviceService, ImportService, SessionUser, AuthorizationError, ValidationError
from enm.core.importers import MobaSession


def setup_db(tmp):
    db=Database(Path(tmp)/"enm.db")
    admin=db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",("admin",hash_password("pass"),"administrator"))
    engineer=db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",("eng",hash_password("pass"),"network_engineer"))
    readonly=db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",("view",hash_password("pass"),"read_only"))
    return db, SessionUser(admin,"admin","administrator"), SessionUser(engineer,"eng","network_engineer"), SessionUser(readonly,"view","read_only")


def test_auth_and_rbac():
    with TemporaryDirectory() as d:
        db, admin, eng, ro=setup_db(d)
        assert AuthService(db).authenticate("eng","pass").role == "network_engineer"
        service=DeviceService(db); service.create(eng,{"name":"core-1","device_type":"switch","ip_address":"10.0.0.1"})
        with pytest.raises(AuthorizationError): service.create(ro,{"name":"x","device_type":"switch"})
        with pytest.raises(ValidationError): service.create(eng,{"name":"bad","device_type":"switch","ip_address":"not-an-ip"})


def test_search_and_transactional_import():
    with TemporaryDirectory() as d:
        db, admin, eng, ro=setup_db(d)
        service=ImportService(db)
        result=service.import_sessions(eng,[MobaSession("KPC\\AG","AG-Core-SW","10.0.0.1",22),MobaSession("KPC\\AG","AG-Access-SW","10.0.0.2",22)],"Ag Site")
        assert result == {"inserted":2,"skipped":0}
        assert len(DeviceService(db).search("10.0.0.2")) == 1
        again=service.import_sessions(eng,[MobaSession("KPC\\AG","AG-Core-SW","10.0.0.1",22)],"Ag Site")
        assert again["skipped"] == 1
