from pathlib import Path
from tempfile import TemporaryDirectory
from enm.core.db import Database
from enm.core.reports import ReportService
from enm.core.license_service import LicenseService


def test_reports_and_trial():
    with TemporaryDirectory() as d:
        db=Database(Path(d)/"enm.db"); db.execute("INSERT INTO devices(name,device_type,status) VALUES(?,?,?)",("core","switch","up")); report=ReportService(db); assert report.dashboard()["devices"] == 1; out=Path(d)/"report.html"; report.export_inventory(out,"html"); assert "core" in out.read_text(); service=LicenseService(db,Path(d)/"public.pem"); status=service.trial_status(); assert status["active"] and status["days_remaining"] == 30
