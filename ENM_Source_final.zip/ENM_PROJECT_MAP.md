# ENM Project Map

## Product boundaries
- `enm/`: engineer-facing desktop application.
- `owner_license_manager/`: separate owner-only license issuing application.
- `tests/`: unit and integration tests.
- `tools/`: Windows packaging and validation scripts.
- `docs/`: security, licensing, installation, user, and QA documentation.

## Core services
- `enm/core/db.py`: schema, migrations, transactions, central device identity.
- `enm/core/security.py`: DPAPI-compatible key envelope abstraction, password hashing, secret encryption.
- `enm/core/licensing.py`: Ed25519 signed offline activation and binding verification.
- `enm/core/audit.py`: append-only audit events without secrets.

## Module status
Dashboard, Inventory, Groups & Devices, Monitoring, IPAM, VLAN, Topology, SNMP, SSH, Alerts, Metrics, Reports, RBAC, Configuration History, Backup/Restore, Audit, Licensing, and Settings are represented in the central architecture. Detailed implementation status is tracked in `ENM_IMPLEMENTATION_STATUS.md`.
