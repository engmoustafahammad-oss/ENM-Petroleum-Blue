# ENM Delivery Policy

The owner requested a single final delivery, not incremental file handoffs.

## Working rule

Intermediate source changes, test artifacts, previews, and internal packages remain inside the project workspace. Do not send release files to the owner during intermediate stages.

## Final delivery only

At final acceptance, deliver one organized release package containing:

1. ENM Windows installer.
2. ENM Owner License Manager installer.
3. Portable distribution where supported.
4. Source archive.
5. Offline license workflow documentation and owner key procedure.
6. Database, security, installation, and user manuals.
7. Automated test report and final requirements audit.
8. MobaXterm import mapping documentation and sanitized import workflow.

## Honesty rule

A feature is only marked PASS after evidence exists. Physical SNMP/SSH tests require an approved lab network. Windows installation, shortcuts, uninstall, upgrade, and packaged GUI tests require a Windows execution environment. If that environment is unavailable, the final report must mark those items NOT TESTED rather than claim completion.
EOF
cat > /home/ubuntu/ENM/TODO.md <<'EOF'
# ENM Final Build TODO

## Core product and architecture
- [ ] Complete all 18 modules as real workflows using the central device identity.
- [ ] Complete dark/light Petroleum Blue design, header, logo, icon, and localization framework.
- [ ] Enforce SQLCipher in production packaging and verify encrypted database headers.
- [ ] Implement Windows DPAPI key wrapping and secure key rotation.

## Network operations
- [ ] Implement inventory bulk editing, hierarchy, groups, IPAM, VLANs, and topology.
- [ ] Implement ICMP monitoring, SNMP v1/v2c/v3 polling, profiles, health checks, and historical metrics.
- [ ] Implement safe interactive SSH terminal, vendor profiles, context-aware autocomplete, and command confirmation.
- [ ] Implement alerts, incidents, reports, configuration history, backup/restore, and audit coverage.

## Identity, licensing, and data
- [ ] Implement Administrator, Network Engineer, and Read Only enforcement at UI and data layers.
- [ ] Complete Credential Vault assignments and connection outcome classification.
- [ ] Complete offline activation request/import, trial, durations, revocation, reassignment, and binding management.
- [ ] Complete CSV/XLSX/JSON/XML/YAML/TXT/HTML/PDF/ZIP/Cfg/Log/MIB/OID workflows where applicable.
- [ ] Complete MobaXterm import mapping, preview, duplicate detection, and transaction rollback.
- [ ] Complete English, Arabic RTL, Spanish, French, German, Chinese, and Russian localization.

## Quality and delivery
- [ ] Run unit and integration tests after each changed subsystem.
- [ ] Build packaged Windows executables and both installers.
- [ ] Validate installation, launch, shortcuts, upgrade, uninstall, and data preservation on Windows.
- [ ] Run approved lab-network tests and document devices/protocols actually tested.
- [ ] Perform final audit and create the single final release package.
EOF
python3 - <<'PY'
from pathlib import Path
p=Path('/home/ubuntu/ENM/ENM_CHANGELOG.md')
s=p.read_text()
s += '\n## Delivery policy update\n- Owner requested final-only delivery; intermediate artifacts remain internal until final acceptance.\n'
p.write_text(s)
PY