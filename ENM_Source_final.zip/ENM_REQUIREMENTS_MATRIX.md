# ENM Requirements Matrix

| Area | Requirement | Status | Evidence / limitation |
|---|---|---:|---|
| Product | Standalone Windows desktop applications | PARTIAL | Source shell created; Windows packaging not executed in Linux sandbox |
| Data | Central device identity and relational integrity | PARTIAL | Initial schema and Inventory import path implemented; full module UI integration pending |
| Security | Encrypted secrets and DPAPI key protection | PARTIAL | Cross-platform envelope service implemented; DPAPI adapter and Windows verification pending |
| Licensing | Offline `.enml`, Ed25519, hardware/SID binding | PARTIAL | Signed payload and binding verifier implemented; Windows owner-key protection pending |
| UI | Petroleum Blue dark/light design system | PARTIAL | Dark shell and approved concept direction implemented; light mode and full visual QA pending |
| Import | MobaXterm session tree preview, deduplication, site mapping | PARTIAL | Parser and confirmation UI implemented; production import acceptance pending |
| Audit | Audit events without secrets | PARTIAL | Service implemented and tested at unit level; complete action coverage pending |
| Network | SNMP/SSH/ICMP with physical devices | NOT TESTED | Requires approved lab devices/network |
| Packaging | ENM installer and License Manager installer | NOT TESTED | Requires Windows build host |
| QA | Automated unit/integration tests | PARTIAL | Core tests included; full suite pending |
