$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --clean --windowed --name ENM --icon enm/resources/enm.ico enm/__main__.py
python -m PyInstaller --noconfirm --clean --windowed --name ENM-Owner-License-Manager --icon enm/resources/enm.ico owner_license_manager/__main__.py
Write-Host 'PyInstaller builds are in dist/. Use Inno Setup or MSIX in the Windows release pipeline to create signed installers.'
