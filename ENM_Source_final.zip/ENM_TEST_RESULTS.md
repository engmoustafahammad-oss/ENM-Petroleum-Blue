# ENM Test Results

| Test group | Result | Notes |
|---|---:|---|
| Python syntax compilation | PASS | `python3 -m compileall -q enm owner_license_manager tests` |
| Core database and foreign keys | PASS | Automated temporary database test |
| Credential encryption round trip | PASS | AES-256-GCM service test |
| Password hashing and verification | PASS | scrypt test |
| License signing and verification | PASS | Ed25519 temporary key test |
| MobaXterm parse, deduplication, and folder extraction | PASS | Automated parser test |
| Audit secret filtering | PASS | Credential-like metadata is removed |
| PySide6 application launch | NOT TESTED | Dependency/runtime not installed in Linux test runner |
| SNMP against physical hardware | NOT TESTED | No lab devices available in sandbox |
| SSH against physical hardware | NOT TESTED | No lab devices available in sandbox |
| Windows installer install/launch/uninstall | NOT TESTED | Linux sandbox cannot execute Windows installer |
