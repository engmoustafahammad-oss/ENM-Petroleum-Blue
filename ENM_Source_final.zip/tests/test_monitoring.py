from pathlib import Path
from tempfile import TemporaryDirectory
from enm.core.db import Database
from enm.core.security import hash_password
from enm.core.services import SessionUser
from enm.core.monitoring import MonitoringService, PingResult, TopologyService


def test_ping_record_and_alerts():
    with TemporaryDirectory(ignore_cleanup_errors=True) as d:
        db=Database(Path(d)/"enm.db"); uid=db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",("eng",hash_password("p"),"network_engineer")); user=SessionUser(uid,"eng","network_engineer")
        did=db.execute("INSERT INTO devices(name,ip_address,device_type) VALUES(?,?,?)",("core","10.0.0.1","switch"))
        runner=lambda host, timeout: PingResult(True, 1.25)
        result=MonitoringService(db,ping_runner=runner).record_ping(user,did,"10.0.0.1")
        assert result.reachable and db.fetch_one("SELECT status FROM devices WHERE id=?",(did,))["status"] == "up"
        assert db.fetch_one("SELECT metric_name FROM metrics WHERE device_id=?",(did,))["metric_name"] == "icmp_latency_ms"
        failing=lambda host, timeout: PingResult(False,None,"Host unreachable")
        MonitoringService(db,ping_runner=failing).record_ping(user,did,"10.0.0.1")
        assert db.fetch_one("SELECT COUNT(*) n FROM alerts WHERE device_id=?",(did,))["n"] == 1


def test_snmp_validation_without_network():
    service=MonitoringService(Database(":memory:"))
    assert service.snmp_get("127.0.0.1","1.3.6.1.2.1.1.1.0",version="2c").success is False
    assert "Community" in service.snmp_get("127.0.0.1","1.3.6.1.2.1.1.1.0",version="2c").error


def test_physical_tree_and_connectivity():
    with TemporaryDirectory(ignore_cleanup_errors=True) as d:
        db=Database(Path(d)/"enm.db"); site=db.execute("INSERT INTO locations(kind,name) VALUES('site','AG')"); room=db.execute("INSERT INTO locations(parent_id,kind,name) VALUES(?,?,?)",(site,'room','Control Room')); a=db.execute("INSERT INTO devices(location_id,name,device_type) VALUES(?,?,?)",(room,'core','switch')); b=db.execute("INSERT INTO devices(location_id,name,device_type) VALUES(?,?,?)",(room,'access','switch')); db.execute("INSERT INTO device_links(source_device_id,target_device_id,source_port,target_port) VALUES(?,?,?,?)",(a,b,'Gi1/0/1','Gi1/0/24'))
        tree=TopologyService(db).physical_tree(); assert tree[0]["name"] == "AG"; assert len(TopologyService(db).connectivity()) == 1
