from pathlib import Path
from tempfile import TemporaryDirectory

from enm.core.db import Database
from enm.core.security import SecretBox, hash_password, verify_password
from enm.core.licensing import create_keypair, issue_license, verify_license


def test_database_and_foreign_keys():
    with TemporaryDirectory(ignore_cleanup_errors=True) as d:
        db = Database(Path(d) / "enm.db")
        site = db.execute("INSERT INTO locations(kind,name) VALUES(?,?)", ("site", "Test Site"))
        device = db.execute("INSERT INTO devices(location_id,name,device_type) VALUES(?,?,?)", (site, "test-switch", "switch"))
        assert db.fetch_one("SELECT name FROM devices WHERE id=?", (device,))["name"] == "test-switch"


def test_secret_box_and_password():
    box = SecretBox(SecretBox.generate_key()); encrypted = box.encrypt_json({"username": "operator", "password": "not-in-logs"})
    assert box.decrypt_json(encrypted)["username"] == "operator"
    encoded = hash_password("strong-password")
    assert verify_password("strong-password", encoded)
    assert not verify_password("wrong", encoded)


def test_offline_license_signature():
    with TemporaryDirectory(ignore_cleanup_errors=True) as d:
        private, public = create_keypair(Path(d))
        license_data = issue_license(private, "Khalda Petroleum", "Engineer 01", "1 Year")
        ok, message = verify_license(license_data, public)
        assert ok, message
