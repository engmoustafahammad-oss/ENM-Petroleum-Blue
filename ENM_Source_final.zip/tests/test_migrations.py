import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory

from enm.core.db import Database


def test_legacy_schema_migration_adds_dashboard_columns():
    with TemporaryDirectory() as d:
        path = Path(d) / "legacy.db"
        conn = sqlite3.connect(path)
        conn.execute("CREATE TABLE schema_version(version INTEGER NOT NULL)")
        conn.execute("INSERT INTO schema_version VALUES(1)")
        conn.execute("CREATE TABLE devices(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, device_type TEXT NOT NULL)")
        conn.execute("CREATE TABLE alerts(id INTEGER PRIMARY KEY, device_id INTEGER, severity TEXT, title TEXT)")
        conn.execute("INSERT INTO devices(name, device_type) VALUES('legacy-switch', 'switch')")
        conn.execute("INSERT INTO alerts(device_id, severity, title) VALUES(1, 'warning', 'Legacy alert')")
        conn.commit()
        conn.close()

        db = Database(path)
        device = db.fetch_one("SELECT serial_number, status FROM devices")
        alert = db.fetch_one("SELECT state, details, resolved_at FROM alerts")

        assert device["serial_number"] is None
        assert device["status"] == "unknown"
        assert alert["state"] == "open"
        assert alert["details"] is None
        assert alert["resolved_at"] is None
