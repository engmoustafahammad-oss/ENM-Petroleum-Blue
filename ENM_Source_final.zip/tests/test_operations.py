from pathlib import Path
from tempfile import TemporaryDirectory
from enm.core.db import Database
from enm.core.security import SecretBox, hash_password
from enm.core.services import SessionUser, AuthorizationError
from enm.core.operations import ConfigurationHistoryService, AlertService, BackupService


def test_config_history_alerts_and_backup():
    with TemporaryDirectory(ignore_cleanup_errors=True) as d:
        db=Database(Path(d)/"enm.db"); uid=db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",("admin",hash_password("p"),"administrator")); user=SessionUser(uid,"admin","administrator"); did=db.execute("INSERT INTO devices(name,device_type) VALUES(?,?)",("core","switch")); box=SecretBox(SecretBox.generate_key())
        history=ConfigurationHistoryService(db,box); rid=history.save(user,did,"enable\nshow version","initial"); assert history.read(user,rid)["configuration"].startswith("enable")
        aid=db.execute("INSERT INTO alerts(device_id,severity,title) VALUES(?,?,?)",(did,"warning","High CPU")); AlertService(db).acknowledge(user,aid); assert db.fetch_one("SELECT state FROM alerts WHERE id=?",(aid,))["state"] == "acknowledged"
        backup=Path(d)/"backup.enmbak"; BackupService(db,box).create(user,backup); assert backup.exists() and backup.stat().st_size > 0
        ro=SessionUser(uid,"viewer","read_only")
        try: BackupService(db,box).create(ro,Path(d)/"nope")
        except AuthorizationError: pass
        else: raise AssertionError("read-only backup should be blocked")
