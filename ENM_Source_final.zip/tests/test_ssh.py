from pathlib import Path
from tempfile import TemporaryDirectory
import pytest
from enm.core.db import Database
from enm.core.security import hash_password
from enm.core.services import SessionUser, AuthorizationError
from enm.core.ssh import SSHService, CommandSafety


def test_command_safety():
    assert CommandSafety.assess("show ip interface brief").classification == "read_only"
    assert CommandSafety.assess("configure terminal").requires_confirmation
    assert CommandSafety.assess("reload").classification == "destructive"


def test_session_history_and_redaction():
    with TemporaryDirectory(ignore_cleanup_errors=True) as d:
        db=Database(Path(d)/"enm.db"); uid=db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",("eng",hash_password("p"),"network_engineer")); user=SessionUser(uid,"eng","network_engineer"); did=db.execute("INSERT INTO devices(name,device_type) VALUES(?,?)",("core","switch")); service=SSHService(db); sid=service.open_session(user,did); assessment=service.record_command(user,sid,"show version",True,"password=supersecret\nversion 17"); assert assessment.classification == "read_only"; row=db.fetch_one("SELECT output_redacted FROM command_history"); assert "supersecret" not in row["output_redacted"]
        with pytest.raises(AuthorizationError): service.record_command(user,sid,"configure terminal",True)
