from pathlib import Path
from tempfile import TemporaryDirectory
import pytest
from enm.core.db import Database
from enm.core.security import hash_password
from enm.core.services import SessionUser, ValidationError
from enm.core.network_profiles import ProfileService


def test_profiles_and_assignment():
    with TemporaryDirectory(ignore_cleanup_errors=True) as d:
        db=Database(Path(d)/"enm.db"); uid=db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",("eng",hash_password("p"),"network_engineer")); user=SessionUser(uid,"eng","network_engineer"); did=db.execute("INSERT INTO devices(name,device_type) VALUES(?,?)",("core","switch")); service=ProfileService(db)
        snmp=service.create_snmp(user,"Default v2c","2c"); ssh=service.create_ssh(user,"Cisco IOS","Cisco IOS"); service.assign_snmp(user,did,snmp); service.assign_ssh(user,did,ssh)
        row=db.fetch_one("SELECT snmp_profile_id,ssh_profile_id FROM devices WHERE id=?",(did,)); assert row["snmp_profile_id"] == snmp and row["ssh_profile_id"] == ssh
        with pytest.raises(ValidationError): service.create_snmp(user,"bad","3")
