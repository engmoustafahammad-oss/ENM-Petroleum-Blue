# ENM Changelog

## 0.1.0-engineering-baseline
- Created clean ENM project from scratch.
- Added persistent architecture and requirements records.
- Added initial security, database, licensing, and packaging foundations.
