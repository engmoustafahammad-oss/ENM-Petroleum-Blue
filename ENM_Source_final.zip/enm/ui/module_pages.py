from __future__ import annotations

import json
from pathlib import Path
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFileDialog, QMessageBox, QLineEdit, QComboBox
from enm.core.db import Database
from enm.core.operations import AlertService, BackupService
from enm.core.reports import ReportService
from enm.core.exchange import ExchangeService
from enm.core.services import SessionUser
from enm.core.security import SecretBox

class ServicePage(QWidget):
    def __init__(self, title: str, db: Database):
        super().__init__(); self.db=db; self.title=title; self.user=SessionUser(0,"local-operator","administrator"); layout=QVBoxLayout(self); layout.setContentsMargins(28,24,28,24); head=QLabel(title); head.setStyleSheet("font-size:26px;font-weight:700;color:#eafcff;"); layout.addWidget(head); self.body=QVBoxLayout(); layout.addLayout(self.body)

class AlertsPage(ServicePage):
    def __init__(self, db):
        super().__init__("Alerts & Incidents",db); controls=QHBoxLayout(); refresh=QPushButton("Refresh"); resolve=QPushButton("Resolve selected"); controls.addWidget(refresh); controls.addWidget(resolve); controls.addStretch(); self.body.addLayout(controls); self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(["ID","Severity","Title","Device","State","Created"]); self.body.addWidget(self.table); refresh.clicked.connect(self.load); resolve.clicked.connect(self.resolve); self.load()
    def load(self):
        rows=self.db.fetch_all("SELECT a.id,a.severity,a.title,COALESCE(d.name,'—') device_name,a.state,a.created_at FROM alerts a LEFT JOIN devices d ON d.id=a.device_id ORDER BY a.created_at DESC"); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,k in enumerate(["id","severity","title","device_name","state","created_at"]): self.table.setItem(i,j,QTableWidgetItem(str(r.get(k) or "—")))
    def resolve(self):
        row=self.table.currentRow()
        if row<0:return
        AlertService(self.db).resolve(self.user,int(self.table.item(row,0).text())); self.load()

class ReportsPage(ServicePage):
    def __init__(self, db):
        super().__init__("Reports",db); self.summary=QLabel(); self.body.addWidget(self.summary); controls=QHBoxLayout(); export=QPushButton("Export inventory report"); controls.addWidget(export); controls.addStretch(); self.body.addLayout(controls); export.clicked.connect(self.export); self.load()
    def load(self): self.summary.setText(json.dumps(ReportService(self.db).dashboard(),indent=2))
    def export(self):
        path,_=QFileDialog.getSaveFileName(self,"Export report",str(Path.home()/"enm_inventory.html"),"HTML (*.html);;CSV (*.csv);;JSON (*.json)");
        if path: ReportService(self.db).export_inventory(path,Path(path).suffix.lstrip('.') or "html"); QMessageBox.information(self,"Reports","Report exported")

class AuditPage(ServicePage):
    def __init__(self, db):
        super().__init__("Audit Logs",db); self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(["Time","Action","Entity","ID","Outcome","Metadata"]); self.body.addWidget(self.table); self.load()
    def load(self):
        rows=self.db.fetch_all("SELECT created_at,action,entity_type,entity_id,outcome,metadata_json FROM audit_events ORDER BY id DESC"); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,k in enumerate(["created_at","action","entity_type","entity_id","outcome","metadata_json"]): self.table.setItem(i,j,QTableWidgetItem(str(r.get(k) or "—")))

class UsersPage(ServicePage):
    def __init__(self, db):
        super().__init__("User Management & RBAC",db); self.table=QTableWidget(0,5); self.table.setHorizontalHeaderLabels(["Username","Role","Enabled","Created","ID"]); self.body.addWidget(self.table); self.load()
    def load(self):
        rows=self.db.fetch_all("SELECT username,role,enabled,created_at,id FROM users ORDER BY username"); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,k in enumerate(["username","role","enabled","created_at","id"]): self.table.setItem(i,j,QTableWidgetItem(str(r.get(k) or "—")))

class BackupPage(ServicePage):
    def __init__(self, db):
        super().__init__("Backup & Restore",db); self.body.addWidget(QLabel("Encrypted backup archives never contain a plaintext production database.")); backup=QPushButton("Create encrypted backup"); self.body.addWidget(backup); backup.clicked.connect(self.create); self.body.addStretch()
    def create(self):
        path,_=QFileDialog.getSaveFileName(self,"Create backup",str(Path.home()/"enm_backup.enmbak"),"ENM Backup (*.enmbak)");
        if path: BackupService(self.db,SecretBox(SecretBox.generate_key())).create(self.user,path); QMessageBox.information(self,"Backup","Encrypted backup created")

class ExchangePage(ServicePage):
    def __init__(self, db):
        super().__init__("Data Import & Export",db); import_btn=QPushButton("Import CSV/JSON devices"); export_btn=QPushButton("Export CSV/JSON devices"); self.body.addWidget(import_btn); self.body.addWidget(export_btn); import_btn.clicked.connect(self.import_devices); export_btn.clicked.connect(self.export_devices); self.body.addStretch()
    def import_devices(self):
        path,_=QFileDialog.getOpenFileName(self,"Import devices",str(Path.home()),"Data (*.csv *.json)");
        if path: result=ExchangeService(self.db).import_devices(self.user,path,Path(path).suffix.lstrip('.')); QMessageBox.information(self,"Import",json.dumps(result))
    def export_devices(self):
        path,_=QFileDialog.getSaveFileName(self,"Export devices",str(Path.home()/"enm_devices.json"),"JSON (*.json);;CSV (*.csv)");
        if path: ExchangeService(self.db).export_devices(path,Path(path).suffix.lstrip('.')); QMessageBox.information(self,"Export","Device data exported")

class SimpleDataPage(ServicePage):
    def __init__(self,title,db,query,headers):
        super().__init__(title,db); self.query=query; self.headers=headers; self.table=QTableWidget(0,len(headers)); self.table.setHorizontalHeaderLabels(headers); self.body.addWidget(self.table); refresh=QPushButton("Refresh"); self.body.addWidget(refresh); refresh.clicked.connect(self.load); self.load()
    def load(self):
        rows=self.db.fetch_all(self.query); self.table.setRowCount(len(rows)); keys=list(rows[0].keys()) if rows else []
        for i,r in enumerate(rows):
            for j,k in enumerate(keys[:len(self.headers)]): self.table.setItem(i,j,QTableWidgetItem(str(r.get(k) or "—")))
