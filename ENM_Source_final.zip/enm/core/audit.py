from __future__ import annotations

import json
from .db import Database

class AuditLog:
    def __init__(self, db: Database): self.db = db
    def record(self, action: str, entity_type: str, entity_id: str | int | None, outcome: str, user_id: int | None = None, metadata: dict | None = None) -> None:
        safe = metadata or {}
        forbidden = {"password", "secret", "token", "community", "private_key", "auth_password", "privacy_password"}
        safe = {k: v for k, v in safe.items() if k.lower() not in forbidden}
        self.db.execute("INSERT INTO audit_events(user_id,action,entity_type,entity_id,outcome,metadata_json) VALUES(?,?,?,?,?,?)", (user_id, action, entity_type, str(entity_id) if entity_id is not None else None, outcome, json.dumps(safe, sort_keys=True)))
