from __future__ import annotations

import base64
import json
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .security import current_user_sid, stable_machine_fingerprint

LICENSE_VERSION = 1

@dataclass
class LicensePayload:
    license_id: str
    customer: str
    engineer: str
    duration: str
    issued_at: str
    activated_at: str | None
    expires_at: str | None
    fingerprint: str
    user_sid: str
    version: int = LICENSE_VERSION


def canonical(payload: LicensePayload) -> bytes:
    return json.dumps(asdict(payload), sort_keys=True, separators=(",", ":")).encode()


def create_keypair(directory: Path) -> tuple[Path, Path]:
    directory.mkdir(parents=True, exist_ok=True)
    private_path, public_path = directory / "owner_ed25519_private.pem", directory / "owner_ed25519_public.pem"
    key = Ed25519PrivateKey.generate()
    private_path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    public_path.write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
    return private_path, public_path


def issue_license(private_key_path: Path, customer: str, engineer: str, duration: str, expires_at: str | None = None, fingerprint: str | None = None, user_sid: str | None = None) -> bytes:
    key = serialization.load_pem_private_key(private_key_path.read_bytes(), password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError("Invalid Ed25519 private key")
    payload = LicensePayload(str(uuid.uuid4()), customer, engineer, duration, datetime.now(timezone.utc).isoformat(), None, expires_at, fingerprint or stable_machine_fingerprint(), user_sid or current_user_sid())
    body = canonical(payload)
    envelope = {"payload": asdict(payload), "signature": base64.b64encode(key.sign(body)).decode(), "algorithm": "Ed25519"}
    return json.dumps(envelope, sort_keys=True, indent=2).encode()


def verify_license(data: bytes, public_key_path: Path, fingerprint: str | None = None, user_sid: str | None = None) -> tuple[bool, str]:
    try:
        envelope = json.loads(data.decode())
        payload = LicensePayload(**envelope["payload"])
        public = serialization.load_pem_public_key(public_key_path.read_bytes())
        public.verify(base64.b64decode(envelope["signature"]), canonical(payload))
        if fingerprint and payload.fingerprint != fingerprint:
            return False, "Hardware binding mismatch"
        if user_sid and payload.user_sid != user_sid:
            return False, "Windows user binding mismatch"
        if payload.expires_at and datetime.fromisoformat(payload.expires_at) < datetime.now(timezone.utc):
            return False, "License expired"
        return True, "License valid"
    except Exception as exc:
        return False, f"Invalid license: {exc}"
