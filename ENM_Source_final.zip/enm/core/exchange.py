from __future__ import annotations

import csv
import json
import ipaddress
from pathlib import Path
from .db import Database
from .services import SessionUser, AuthService, ValidationError

FIELDS = ["name","hostname","ip_address","mac_address","serial_number","vendor","model","device_type","os_name","firmware_version","status"]

class ExchangeService:
    def __init__(self, db: Database): self.db=db; self.auth=AuthService(db)
    def export_devices(self, path: Path | str, fmt: str = "json") -> Path:
        path=Path(path); rows=self.db.fetch_all("SELECT "+",".join(FIELDS)+" FROM devices ORDER BY name")
        if fmt.lower() == "json": path.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding="utf-8")
        elif fmt.lower() == "csv":
            with path.open("w",newline="",encoding="utf-8") as f: writer=csv.DictWriter(f,fieldnames=FIELDS); writer.writeheader(); writer.writerows(rows)
        else: raise ValueError("Supported device export formats are CSV and JSON")
        return path
    def import_devices(self, user: SessionUser, path: Path | str, fmt: str = "json") -> dict[str,int]:
        self.auth.require_role(user); path=Path(path)
        if fmt.lower() == "json": rows=json.loads(path.read_text(encoding="utf-8"))
        elif fmt.lower() == "csv":
            with path.open(newline="",encoding="utf-8") as f: rows=list(csv.DictReader(f))
        else: raise ValueError("Supported device import formats are CSV and JSON")
        if not isinstance(rows,list): raise ValidationError("Import must contain a list of devices")
        inserted=skipped=invalid=0
        with self.db.transaction() as conn:
            for row in rows:
                name=str(row.get("name") or "").strip(); ip=str(row.get("ip_address") or "").strip()
                if not name or (ip and not self._valid_ip(ip)): invalid+=1; continue
                if conn.execute("SELECT 1 FROM devices WHERE name=?",(name,)).fetchone(): skipped+=1; continue
                values={field:row.get(field) or None for field in FIELDS}; values["name"]=name; values["device_type"]=values["device_type"] or "network_device"; values["status"]=values["status"] or "unknown"
                conn.execute("INSERT INTO devices("+",".join(FIELDS)+") VALUES("+",".join(":"+f for f in FIELDS)+")",values); inserted+=1
        return {"inserted":inserted,"skipped":skipped,"invalid":invalid}
    @staticmethod
    def _valid_ip(value: str) -> bool:
        try: ipaddress.ip_address(value); return True
        except ValueError: return False
