from __future__ import annotations

import platform
import re
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from .audit import AuditLog
from .db import Database
from .services import SessionUser, AuthorizationError

@dataclass(frozen=True)
class PingResult:
    reachable: bool
    latency_ms: float | None
    error: str | None = None

@dataclass(frozen=True)
class SnmpResult:
    success: bool
    oid: str
    value: str | None
    error: str | None = None

class MonitoringService:
    def __init__(self, db: Database, audit: AuditLog | None = None, ping_runner: Callable | None = None):
        self.db, self.audit, self.ping_runner = db, audit or AuditLog(db), ping_runner

    def ping(self, host: str, timeout_seconds: int = 2) -> PingResult:
        started = time.perf_counter()
        if self.ping_runner:
            return self.ping_runner(host, timeout_seconds)
        flag = "-n" if platform.system() == "Windows" else "-c"
        timeout_flag = "-w" if platform.system() == "Windows" else "-W"
        command = ["ping", flag, "1", timeout_flag, str(timeout_seconds * 1000 if platform.system() == "Windows" else timeout_seconds), host]
        try:
            completed = subprocess.run(command, capture_output=True, text=True, timeout=timeout_seconds + 2)
            if completed.returncode != 0: return PingResult(False, None, "Host unreachable")
            return PingResult(True, round((time.perf_counter() - started) * 1000, 2))
        except subprocess.TimeoutExpired: return PingResult(False, None, "Connection timeout")
        except OSError as exc: return PingResult(False, None, str(exc))

    def record_ping(self, user: SessionUser, device_id: int, host: str) -> PingResult:
        result = self.ping(host)
        now = datetime.now(timezone.utc).isoformat()
        status = "up" if result.reachable else "down"
        with self.db.transaction() as conn:
            conn.execute("UPDATE devices SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (status, device_id))
            if result.latency_ms is not None: conn.execute("INSERT INTO metrics(device_id,metric_name,value,collected_at) VALUES(?,?,?,?)", (device_id, "icmp_latency_ms", result.latency_ms, now))
            if not result.reachable: conn.execute("INSERT INTO alerts(device_id,severity,title,details) VALUES(?,?,?,?)", (device_id, "critical", "Device unreachable", result.error or "Ping failed"))
        self.audit.record("monitor_ping", "device", device_id, "success" if result.reachable else "failure", user.id, {"host": host, "reachable": result.reachable})
        return result

    def snmp_get(self, host: str, oid: str, version: str = "2c", community: str | None = None, username: str | None = None, auth_secret: str | None = None, privacy_secret: str | None = None, port: int = 161) -> SnmpResult:
        if version not in {"1", "2c", "3"}: return SnmpResult(False, oid, None, "Unsupported SNMP version")
        if version in {"1", "2c"} and not community: return SnmpResult(False, oid, None, "Community is required for SNMP v1/v2c")
        if version == "3" and not username: return SnmpResult(False, oid, None, "Username is required for SNMP v3")
        try:
            from pysnmp.hlapi import getCmd, SnmpEngine, CommunityData, UdpTransportTarget, ContextData, ObjectType, ObjectIdentity
            if version == "3": return SnmpResult(False, oid, None, "SNMPv3 adapter requires configured USM profile")
            mp_model = 0 if version == "1" else 1
            iterator = getCmd(SnmpEngine(), CommunityData(community, mpModel=mp_model), UdpTransportTarget((host, port), timeout=2, retries=1), ContextData(), ObjectType(ObjectIdentity(oid)))
            error_indication, error_status, error_index, var_binds = next(iterator)
            if error_indication: return SnmpResult(False, oid, None, str(error_indication))
            if error_status: return SnmpResult(False, oid, None, str(error_status))
            return SnmpResult(True, oid, str(var_binds[0][1]) if var_binds else None)
        except ImportError: return SnmpResult(False, oid, None, "pysnmp is not installed")
        except Exception as exc: return SnmpResult(False, oid, None, str(exc))

    def record_snmp(self, user: SessionUser, device_id: int, host: str, oid: str, **kwargs) -> SnmpResult:
        if user.role == "read_only": raise AuthorizationError("Monitoring action requires an engineering role")
        result = self.snmp_get(host, oid, **kwargs)
        if result.success:
            try:
                value = float(result.value)
                self.db.execute("INSERT INTO metrics(device_id,metric_name,value) VALUES(?,?,?)", (device_id, f"snmp:{oid}", value))
            except (TypeError, ValueError): pass
        self.audit.record("snmp_get", "device", device_id, "success" if result.success else "failure", user.id, {"host": host, "oid": oid, "version": kwargs.get("version", "2c")})
        return result

class TopologyService:
    def __init__(self, db: Database): self.db = db
    def physical_tree(self) -> list[dict]:
        locations = self.db.fetch_all("SELECT id,parent_id,kind,name FROM locations ORDER BY kind,name")
        devices = self.db.fetch_all("SELECT id,location_id,name,ip_address,status,device_type FROM devices ORDER BY name")
        by_parent: dict[int | None, list[dict]] = {}
        for item in locations: by_parent.setdefault(item["parent_id"], []).append({**item, "children": []})
        nodes = {item["id"]: item for group in by_parent.values() for item in group}
        for item in locations:
            if item["parent_id"] in nodes: nodes[item["parent_id"]]["children"].append(nodes[item["id"]])
        for device in devices:
            node = nodes.get(device["location_id"])
            if node: node["children"].append({"kind":"device", **device, "children": []})
        return by_parent.get(None, [])
    def connectivity(self) -> list[dict]:
        return self.db.fetch_all("""SELECT l.source_device_id,l.target_device_id,l.source_port,l.target_port,l.link_type,
            s.name source_name,t.name target_name FROM device_links l JOIN devices s ON s.id=l.source_device_id JOIN devices t ON t.id=l.target_device_id""")
