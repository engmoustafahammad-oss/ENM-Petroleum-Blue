from __future__ import annotations

import csv
import io
import ipaddress
import re
from dataclasses import dataclass
from pathlib import Path

@dataclass
class MobaSession:
    group: str
    name: str
    host: str
    port: int
    protocol: str = "ssh"


def parse_mobaxterm(path: Path | str) -> list[MobaSession]:
    """Parse session names, folders, endpoints, and ports only.

    Passwords, tokens, and private connection fields are intentionally not imported.
    The parser supports preview/deduplication before database insertion.
    """
    group = "Uncategorized"
    sessions: list[MobaSession] = []
    for raw in Path(path).read_text(errors="replace").splitlines():
        if raw.startswith("SubRep="):
            group = raw.split("=", 1)[1] or "Uncategorized"
            continue
        if "=" not in raw or raw.startswith(("ImgNum=", "Serial (COM)")):
            continue
        name, encoded = raw.split("=", 1)
        parts = encoded.split("%")
        if len(parts) < 3:
            continue
        host = parts[1].strip()
        try:
            port = int(parts[2])
            ipaddress.ip_address(host)
        except (ValueError, IndexError):
            continue
        protocol = "ssh" if port in {22, 23} else "remote"
        sessions.append(MobaSession(group, name.strip(), host, port, protocol))
    return sessions


def deduplicate(sessions: list[MobaSession]) -> list[MobaSession]:
    seen: set[tuple[str, str, int]] = set(); result=[]
    for session in sessions:
        key=(session.name.lower(),session.host,session.port)
        if key not in seen: seen.add(key); result.append(session)
    return result


def export_preview_csv(sessions: list[MobaSession], path: Path | str, limit: int | None = None) -> None:
    rows = sessions if limit is None else sessions[:limit]
    with Path(path).open("w", newline="", encoding="utf-8") as f:
        writer=csv.writer(f); writer.writerow(["group","name","host","port","protocol"])
        writer.writerows((s.group,s.name,s.host,s.port,s.protocol) for s in rows)
