from __future__ import annotations

import csv
import html
import json
from pathlib import Path
from .db import Database

class ReportService:
    def __init__(self, db: Database): self.db=db
    def dashboard(self) -> dict:
        return {
            "devices": self.db.fetch_one("SELECT COUNT(*) n FROM devices")["n"],
            "sites": self.db.fetch_one("SELECT COUNT(*) n FROM locations WHERE kind='site'")["n"],
            "open_alerts": self.db.fetch_one("SELECT COUNT(*) n FROM alerts WHERE state='open'")["n"],
            "reachable": self.db.fetch_one("SELECT COUNT(*) n FROM devices WHERE status='up'")["n"],
            "unreachable": self.db.fetch_one("SELECT COUNT(*) n FROM devices WHERE status='down'")["n"],
            "metrics": self.db.fetch_one("SELECT COUNT(*) n FROM metrics")["n"],
        }
    def inventory_rows(self) -> list[dict]: return self.db.fetch_all("SELECT d.*,l.name location_name FROM devices d LEFT JOIN locations l ON l.id=d.location_id ORDER BY d.name")
    def export_inventory(self, path: Path | str, fmt: str = "html") -> Path:
        path=Path(path); rows=self.inventory_rows()
        if fmt == "json": path.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding="utf-8")
        elif fmt == "csv":
            keys=["name","ip_address","serial_number","vendor","model","device_type","status","location_name"]
            with path.open("w",newline="",encoding="utf-8") as f: writer=csv.DictWriter(f,fieldnames=keys); writer.writeheader(); writer.writerows({k:r.get(k) for k in keys} for r in rows)
        elif fmt == "html":
            head="<tr>"+"".join(f"<th>{html.escape(k)}</th>" for k in ["name","ip_address","vendor","model","device_type","status","location_name"])+"</tr>"
            body="".join("<tr>"+"".join(f"<td>{html.escape(str(r.get(k) or ''))}</td>" for k in ["name","ip_address","vendor","model","device_type","status","location_name"])+"</tr>" for r in rows)
            path.write_text("<!doctype html><meta charset='utf-8'><title>ENM Inventory Report</title><table>"+head+body+"</table>",encoding="utf-8")
        else: raise ValueError("Supported report formats are HTML, CSV, and JSON")
        return path
