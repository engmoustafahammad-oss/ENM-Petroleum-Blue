from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from .db import Database
from .licensing import verify_license
from .security import current_user_sid, stable_machine_fingerprint

class LicenseService:
    def __init__(self, db: Database, public_key_path: Path): self.db,self.public_key_path=db,public_key_path
    def activation_request(self, path: Path | str, engineer: str) -> Path:
        payload={"engineer":engineer,"fingerprint":stable_machine_fingerprint(),"user_sid":current_user_sid(),"created_at":datetime.now(timezone.utc).isoformat()}
        path=Path(path); path.write_text(json.dumps(payload,indent=2),encoding="utf-8"); return path
    def import_license(self, path: Path | str) -> tuple[bool,str]:
        data=Path(path).read_bytes(); ok,message=verify_license(data,self.public_key_path,stable_machine_fingerprint(),current_user_sid())
        if not ok: return False,message
        payload=json.loads(data.decode())["payload"]
        self.db.execute("INSERT OR REPLACE INTO licenses(license_id,customer,engineer,issued_at,activated_at,expires_at,status,fingerprint,user_sid) VALUES(?,?,?,?,?,?,?,?,?)",(payload["license_id"],payload["customer"],payload["engineer"],payload["issued_at"],datetime.now(timezone.utc).isoformat(),payload["expires_at"],"active",payload["fingerprint"],payload["user_sid"]))
        return True,"License activated"
    def trial_status(self) -> dict:
        row=self.db.fetch_one("SELECT value FROM app_settings WHERE key='trial_started_at'")
        if not row:
            started=datetime.now(timezone.utc); self.db.execute("INSERT INTO app_settings(key,value) VALUES('trial_started_at',?)",(started.isoformat(),)); return {"active":True,"days_remaining":30}
        started=datetime.fromisoformat(row["value"]); remaining=max(0,30-(datetime.now(timezone.utc)-started).days); return {"active":remaining>0,"days_remaining":remaining}
    def status(self) -> dict:
        active=self.db.fetch_one("SELECT * FROM licenses WHERE status='active' ORDER BY id DESC LIMIT 1")
        return {"licensed":bool(active),"license":active,"trial":self.trial_status() if not active else None}
