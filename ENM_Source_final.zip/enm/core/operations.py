from __future__ import annotations

import json
import base64
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from .db import Database
from .security import EncryptedSecret, SecretBox
from .services import SessionUser, AuthService, AuthorizationError
from .audit import AuditLog

class ConfigurationHistoryService:
    def __init__(self, db: Database, secret_box: SecretBox, audit: AuditLog | None = None): self.db,self.box,self.audit=db,secret_box,audit or AuditLog(db)
    def save(self, user: SessionUser, device_id: int, configuration: str, description: str = "") -> int:
        AuthService(self.db).require_role(user); latest=self.db.fetch_one("SELECT COALESCE(MAX(revision),0) revision FROM configuration_revisions WHERE device_id=?",(device_id,))["revision"]; secret=self.box.encrypt_json({"configuration":configuration}); revision=int(latest)+1
        rid=self.db.execute("INSERT INTO configuration_revisions(device_id,revision,content_encrypted,nonce,user_id,description) VALUES(?,?,?,?,?,?)",(device_id,revision,secret.ciphertext,secret.nonce,user.id,description)); self.audit.record("config_save","device",device_id,"success",user.id,{"revision":revision}); return rid
    def read(self, user: SessionUser, revision_id: int) -> dict:
        row=self.db.fetch_one("SELECT * FROM configuration_revisions WHERE id=?",(revision_id,))
        if not row: raise KeyError("Configuration revision not found")
        return {**row, **self.box.decrypt_json(EncryptedSecret(row["content_encrypted"],row["nonce"]))}
    def list(self, device_id: int) -> list[dict]: return self.db.fetch_all("SELECT id,device_id,revision,user_id,description,created_at FROM configuration_revisions WHERE device_id=? ORDER BY revision DESC",(device_id,))

class AlertService:
    def __init__(self, db: Database, audit: AuditLog | None = None): self.db,self.audit=db,audit or AuditLog(db)
    def list_open(self) -> list[dict]: return self.db.fetch_all("SELECT a.*,d.name device_name,d.ip_address FROM alerts a LEFT JOIN devices d ON d.id=a.device_id WHERE a.state='open' ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'warning' THEN 2 ELSE 3 END,created_at DESC")
    def resolve(self, user: SessionUser, alert_id: int) -> None:
        if user.role == "read_only": raise AuthorizationError("Read-only users cannot resolve incidents")
        self.db.execute("UPDATE alerts SET state='resolved',resolved_at=CURRENT_TIMESTAMP WHERE id=?",(alert_id,)); self.audit.record("alert_resolve","alert",alert_id,"success",user.id)
    def acknowledge(self, user: SessionUser, alert_id: int) -> None:
        if user.role == "read_only": raise AuthorizationError("Read-only users cannot acknowledge incidents")
        self.db.execute("UPDATE alerts SET state='acknowledged' WHERE id=?",(alert_id,)); self.audit.record("alert_ack","alert",alert_id,"success",user.id)

class BackupService:
    def __init__(self, db: Database, secret_box: SecretBox, audit: AuditLog | None = None): self.db,self.box,self.audit=db,secret_box,audit or AuditLog(db)
    def create(self, user: SessionUser, destination: Path | str) -> Path:
        if user.role != "administrator": raise AuthorizationError("Only administrators can create backups")
        destination=Path(destination); tables=["locations","devices","credentials","snmp_profiles","ssh_profiles","ipam_records","vlans","device_links","metrics","alerts","configuration_revisions","audit_events","licenses","app_settings"]
        payload={}
        for table in tables:
            rows=self.db.fetch_all(f"SELECT * FROM {table}")
            payload[table]=[{key:(base64.b64encode(value).decode("ascii") if isinstance(value, bytes) else value) for key,value in row.items()} for row in rows]
        encrypted=self.box.encrypt_json({"created_at":datetime.now(timezone.utc).isoformat(),"tables":payload})
        with zipfile.ZipFile(destination,"w",zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("enm-backup.json.enc", encrypted.ciphertext); archive.writestr("enm-backup.nonce", encrypted.nonce)
        self.audit.record("backup_create","backup",destination.name,"success",user.id,{"tables":len(tables)}); return destination
