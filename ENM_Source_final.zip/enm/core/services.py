from __future__ import annotations

import ipaddress
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from .audit import AuditLog
from .db import Database
from .security import verify_password

ROLES = {"administrator", "network_engineer", "read_only"}
WRITE_ROLES = {"administrator", "network_engineer"}

@dataclass(frozen=True)
class SessionUser:
    id: int
    username: str
    role: str

class AuthorizationError(PermissionError):
    pass

class ValidationError(ValueError):
    pass

class AuthService:
    def __init__(self, db: Database): self.db = db
    def authenticate(self, username: str, password: str) -> SessionUser | None:
        row = self.db.fetch_one("SELECT id,username,password_hash,role FROM users WHERE username=? AND enabled=1", (username.strip(),))
        if not row or not verify_password(password, row["password_hash"]): return None
        return SessionUser(row["id"], row["username"], row["role"])
    def require_role(self, user: SessionUser, allowed: set[str] = WRITE_ROLES) -> None:
        if user.role not in allowed: raise AuthorizationError(f"Role {user.role} is not allowed for this operation")

class DeviceService:
    def __init__(self, db: Database, audit: AuditLog | None = None): self.db, self.audit, self.auth = db, audit or AuditLog(db), AuthService(db)
    def _validate(self, data: dict[str, Any]) -> None:
        if not str(data.get("name", "")).strip(): raise ValidationError("Device name is required")
        if not str(data.get("device_type", "")).strip(): raise ValidationError("Device type is required")
        if data.get("ip_address"):
            try: ipaddress.ip_address(data["ip_address"])
            except ValueError as exc: raise ValidationError("Invalid IP address") from exc
    def create(self, user: SessionUser, data: dict[str, Any]) -> int:
        self.auth.require_role(user); self._validate(data)
        values = {field: data.get(field) for field in ("location_id", "name", "hostname", "ip_address", "mac_address", "serial_number", "vendor", "model", "device_type", "os_name", "firmware_version")}
        values["status"] = data.get("status", "unknown")
        with self.db.transaction() as conn:
            cur = conn.execute("""INSERT INTO devices(location_id,name,hostname,ip_address,mac_address,serial_number,vendor,model,device_type,os_name,firmware_version,status)
                VALUES(:location_id,:name,:hostname,:ip_address,:mac_address,:serial_number,:vendor,:model,:device_type,:os_name,:firmware_version,:status)""", values)
            device_id = int(cur.lastrowid)
        self.audit.record("create", "device", device_id, "success", user.id, {"name": data["name"]}); return device_id
    def update(self, user: SessionUser, device_id: int, data: dict[str, Any]) -> None:
        self.auth.require_role(user); self._validate({"name": data.get("name"), "device_type": data.get("device_type"), "ip_address": data.get("ip_address")})
        fields = ["location_id","name","hostname","ip_address","mac_address","serial_number","vendor","model","device_type","os_name","firmware_version","status"]
        values = {k: data.get(k) for k in fields}; values["id"] = device_id
        with self.db.transaction() as conn: conn.execute("UPDATE devices SET " + ",".join(f"{f}=:{f}" for f in fields) + ",updated_at=CURRENT_TIMESTAMP WHERE id=:id", values)
        self.audit.record("update", "device", device_id, "success", user.id, {"name": data.get("name")})
    def delete(self, user: SessionUser, device_id: int) -> None:
        if user.role != "administrator": raise AuthorizationError("Only administrators can delete devices")
        self.db.execute("DELETE FROM devices WHERE id=?", (device_id,)); self.audit.record("delete", "device", device_id, "success", user.id)
    def search(self, query: str = "", filters: dict[str, Any] | None = None) -> list[dict]:
        filters = filters or {}; clauses=[]; params=[]
        if query.strip():
            like=f"%{query.strip()}%"; clauses.append("(name LIKE ? OR ip_address LIKE ? OR serial_number LIKE ? OR vendor LIKE ? OR model LIKE ? OR hostname LIKE ?)"); params.extend([like]*6)
        for field in ("device_type","status","vendor","location_id"):
            if filters.get(field) not in (None, ""): clauses.append(f"{field}=?"); params.append(filters[field])
        where=" WHERE "+" AND ".join(clauses) if clauses else ""
        return self.db.fetch_all("SELECT * FROM devices"+where+" ORDER BY name", tuple(params))

class ImportService:
    def __init__(self, db: Database, audit: AuditLog | None = None): self.db, self.audit = db, audit or AuditLog(db)
    def import_sessions(self, user: SessionUser, sessions: list[Any], site_name: str | None = None) -> dict[str, int]:
        if user.role not in WRITE_ROLES: raise AuthorizationError("Import requires write permission")
        inserted = skipped = 0
        with self.db.transaction() as conn:
            location_id = None
            if site_name:
                row=conn.execute("SELECT id FROM locations WHERE kind='site' AND name=?", (site_name,)).fetchone()
                location_id = row[0] if row else conn.execute("INSERT INTO locations(kind,name) VALUES('site',?)", (site_name,)).lastrowid
            for session in sessions:
                if conn.execute("SELECT 1 FROM devices WHERE name=?", (session.name,)).fetchone(): skipped += 1; continue
                conn.execute("INSERT INTO devices(location_id,name,hostname,ip_address,device_type,status) VALUES(?,?,?,?,?,?)", (location_id, session.name, session.name, session.host, "network_device", "unknown")); inserted += 1
        self.audit.record("import", "device_batch", None, "success", user.id, {"inserted": inserted, "skipped": skipped, "source": "mobaxterm"})
        return {"inserted": inserted, "skipped": skipped}
