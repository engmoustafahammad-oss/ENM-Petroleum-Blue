from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any
from .audit import AuditLog
from .db import Database
from .services import SessionUser, AuthService, AuthorizationError

READ_ONLY = {"show", "display", "get", "ping", "traceroute", "tracert", "dir", "ls", "cat", "version", "inventory"}
DESTRUCTIVE = {"reload", "erase", "delete", "format", "write erase", "crypto key zeroize", "factory-reset", "shutdown"}
COMMANDS = {
    "Cisco IOS": ["show interfaces", "show ip interface brief", "show vlan brief", "show mac address-table", "show running-config", "show version", "show inventory", "show ip route", "show spanning-tree", "show cdp neighbors"],
    "Cisco NX-OS": ["show interface brief", "show vlan", "show mac address-table", "show version", "show cdp neighbors detail", "show vpc"],
    "Huawei VRP": ["display interface brief", "display vlan", "display version", "display ip routing-table", "display current-configuration"],
    "Juniper Junos": ["show interfaces terse", "show vlans", "show version", "show route", "show configuration"],
    "Aruba AOS-CX": ["show interface brief", "show vlan", "show version", "show lldp neighbor-info"],
}

@dataclass(frozen=True)
class CommandAssessment:
    classification: str
    requires_confirmation: bool
    reason: str

class CommandSafety:
    @staticmethod
    def assess(command: str) -> CommandAssessment:
        normalized = re.sub(r"\s+", " ", command.strip().lower())
        if not normalized: return CommandAssessment("empty", False, "Empty command")
        if any(normalized == item or normalized.startswith(item + " ") for item in DESTRUCTIVE): return CommandAssessment("destructive", True, "Potentially destructive command")
        if any(normalized == item or normalized.startswith(item + " ") for item in READ_ONLY): return CommandAssessment("read_only", False, "Read-only inspection command")
        return CommandAssessment("configuration_changing", True, "Command may change device state")

class SSHService:
    def __init__(self, db: Database, audit: AuditLog | None = None): self.db, self.audit, self.auth = db, audit or AuditLog(db), AuthService(db)
    def suggestions(self, vendor_os: str, prefix: str) -> list[str]:
        commands=COMMANDS.get(vendor_os, [])
        p=prefix.strip().lower(); return [cmd for cmd in commands if cmd.lower().startswith(p)] if p else commands
    def open_session(self, user: SessionUser, device_id: int) -> int:
        self.auth.require_role(user)
        session=self.db.execute("INSERT INTO ssh_sessions(device_id,user_id,state) VALUES(?,?,?)",(device_id,user.id,"open")); self.audit.record("ssh_open","device",device_id,"success",user.id); return session
    def record_command(self, user: SessionUser, session_id: int, command: str, executed: bool = False, output: str | None = None) -> CommandAssessment:
        assessment=CommandSafety.assess(command)
        if executed and user.role == "read_only": raise AuthorizationError("Read-only users cannot execute SSH commands")
        if executed and assessment.requires_confirmation: raise AuthorizationError("Explicit confirmation is required before this command")
        redacted = None if output is None else re.sub(r"(?i)(password|secret|community)\s*[:=]\s*\S+", r"\1=[REDACTED]", output)
        self.db.execute("INSERT INTO command_history(session_id,command,classification,executed,output_redacted) VALUES(?,?,?,?,?)",(session_id,command,assessment.classification,int(executed),redacted))
        self.audit.record("ssh_command","session",session_id,"success",user.id,{"classification":assessment.classification,"executed":executed})
        return assessment
    def close_session(self, user: SessionUser, session_id: int) -> None:
        self.db.execute("UPDATE ssh_sessions SET state='closed',ended_at=CURRENT_TIMESTAMP WHERE id=?",(session_id,)); self.audit.record("ssh_close","session",session_id,"success",user.id)
