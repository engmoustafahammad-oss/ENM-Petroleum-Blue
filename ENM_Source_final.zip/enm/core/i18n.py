from __future__ import annotations

import json
from pathlib import Path

TRANSLATIONS = {
    "en": {"app_name":"Enterprise Network Manager","dashboard":"Dashboard","inventory":"Network Inventory","topology":"Network Topology","monitoring":"Network Monitoring","settings":"System Settings","import":"Import","refresh":"Refresh","healthy":"Healthy","unknown":"Unknown"},
    "ar": {"app_name":"مدير شبكات المؤسسات","dashboard":"لوحة المعلومات","inventory":"جرد الشبكة","topology":"طوبولوجيا الشبكة","monitoring":"مراقبة الشبكة","settings":"إعدادات النظام","import":"استيراد","refresh":"تحديث","healthy":"سليم","unknown":"غير معروف"},
    "es": {"app_name":"Administrador de Redes Empresariales","dashboard":"Panel","inventory":"Inventario de red","topology":"Topología de red","monitoring":"Monitoreo de red","settings":"Configuración","import":"Importar","refresh":"Actualizar","healthy":"Correcto","unknown":"Desconocido"},
    "fr": {"app_name":"Gestionnaire de réseau d'entreprise","dashboard":"Tableau de bord","inventory":"Inventaire réseau","topology":"Topologie réseau","monitoring":"Surveillance réseau","settings":"Paramètres","import":"Importer","refresh":"Actualiser","healthy":"Sain","unknown":"Inconnu"},
    "de": {"app_name":"Enterprise-Netzwerkmanager","dashboard":"Dashboard","inventory":"Netzwerkinventar","topology":"Netzwerktopologie","monitoring":"Netzwerküberwachung","settings":"Systemeinstellungen","import":"Importieren","refresh":"Aktualisieren","healthy":"OK","unknown":"Unbekannt"},
    "zh": {"app_name":"企业网络管理器","dashboard":"仪表板","inventory":"网络资产","topology":"网络拓扑","monitoring":"网络监控","settings":"系统设置","import":"导入","refresh":"刷新","healthy":"正常","unknown":"未知"},
    "ru": {"app_name":"Менеджер корпоративной сети","dashboard":"Панель управления","inventory":"Инвентарь сети","topology":"Топология сети","monitoring":"Мониторинг сети","settings":"Системные настройки","import":"Импорт","refresh":"Обновить","healthy":"Работает","unknown":"Неизвестно"},
}

class Translator:
    def __init__(self, language: str = "en"): self.language = language if language in TRANSLATIONS else "en"
    @property
    def rtl(self) -> bool: return self.language == "ar"
    def set_language(self, language: str) -> None:
        if language not in TRANSLATIONS: raise ValueError("Unsupported language")
        self.language = language
    def t(self, key: str) -> str: return TRANSLATIONS[self.language].get(key, TRANSLATIONS["en"].get(key, key))
    def export_pack(self, path: Path | str) -> None: Path(path).write_text(json.dumps(TRANSLATIONS[self.language], ensure_ascii=False, indent=2), encoding="utf-8")
