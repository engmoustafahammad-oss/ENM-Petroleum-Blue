from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import platform
import secrets
from dataclasses import dataclass

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:  # optional dependency; installation is required for production
    AESGCM = None


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return f"scrypt${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        _, salt_b64, digest_b64 = encoded.split("$", 2)
        salt = base64.urlsafe_b64decode(salt_b64)
        expected = base64.urlsafe_b64decode(digest_b64)
        actual = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


@dataclass(frozen=True)
class EncryptedSecret:
    ciphertext: bytes
    nonce: bytes


class SecretBox:
    """AES-256-GCM secret service.

    Production Windows builds must wrap the generated master key using Windows DPAPI.
    This class deliberately does not persist a key or include one in source code.
    """
    def __init__(self, key: bytes):
        if AESGCM is None:
            raise RuntimeError("cryptography is required for secret protection")
        if len(key) != 32:
            raise ValueError("AES-256 requires a 32-byte key")
        self._aead = AESGCM(key)

    @staticmethod
    def generate_key() -> bytes:
        return AESGCM.generate_key(bit_length=256) if AESGCM else os.urandom(32)

    def encrypt_json(self, value: dict) -> EncryptedSecret:
        nonce = os.urandom(12)
        ciphertext = self._aead.encrypt(nonce, json.dumps(value, sort_keys=True).encode(), None)
        return EncryptedSecret(ciphertext, nonce)

    def decrypt_json(self, secret: EncryptedSecret) -> dict:
        raw = self._aead.decrypt(secret.nonce, secret.ciphertext, None)
        return json.loads(raw.decode())


def stable_machine_fingerprint() -> str:
    """Best-effort fingerprint input; final Windows adapter adds stable hardware IDs."""
    material = "|".join([platform.system(), platform.node(), platform.machine(), platform.processor()])
    return hashlib.sha256(material.encode()).hexdigest()


def current_user_sid() -> str:
    if platform.system() == "Windows":
        try:
            import ctypes
            import subprocess
            sid = subprocess.check_output(
                ["whoami", "/user", "/fo", "csv", "/nh"],
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip().strip('"').split('","')[0]
            if sid.startswith("S-"):
                return sid
        except Exception:
            pass
    return os.environ.get("USERNAME") or os.environ.get("USER") or "unknown-user"
