from __future__ import annotations

from .db import Database
from .services import SessionUser, AuthService, ValidationError

SUPPORTED_VENDORS = {
    "Cisco IOS", "Cisco IOS-XE", "Cisco NX-OS", "Huawei VRP", "ArubaOS", "Aruba AOS-CX",
    "Fortinet FortiOS", "Juniper Junos", "HPE Comware", "HPE Aruba", "MikroTik RouterOS",
    "Dell OS10", "Ubiquiti", "Generic SNMP",
}

class ProfileService:
    def __init__(self, db: Database): self.db, self.auth = db, AuthService(db)
    def create_snmp(self, user: SessionUser, name: str, version: str, credential_id: int | None = None, **kwargs) -> int:
        self.auth.require_role(user)
        if version not in {"1", "2c", "3"}: raise ValidationError("SNMP version must be 1, 2c, or 3")
        if version == "3" and not kwargs.get("security_level"): raise ValidationError("SNMPv3 security level is required")
        return self.db.execute("INSERT INTO snmp_profiles(name,version,port,security_level,auth_protocol,privacy_protocol,credential_id) VALUES(?,?,?,?,?,?,?)", (name.strip(),version,int(kwargs.get("port",161)),kwargs.get("security_level"),kwargs.get("auth_protocol"),kwargs.get("privacy_protocol"),credential_id))
    def create_ssh(self, user: SessionUser, name: str, vendor_os: str, credential_id: int | None = None, port: int = 22) -> int:
        self.auth.require_role(user)
        if vendor_os not in SUPPORTED_VENDORS: raise ValidationError("Vendor profile is not supported")
        return self.db.execute("INSERT INTO ssh_profiles(name,port,credential_id,vendor_os) VALUES(?,?,?,?)", (name.strip(),port,credential_id,vendor_os))
    def assign_snmp(self, user: SessionUser, device_id: int, profile_id: int) -> None:
        self.auth.require_role(user); self.db.execute("UPDATE devices SET snmp_profile_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (profile_id, device_id))
    def assign_ssh(self, user: SessionUser, device_id: int, profile_id: int) -> None:
        self.auth.require_role(user); self.db.execute("UPDATE devices SET ssh_profile_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (profile_id, device_id))
