from __future__ import annotations

import sys
from pathlib import Path
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel, QHBoxLayout, QListWidget,
    QStackedWidget, QTableWidget, QTableWidgetItem, QPushButton, QStatusBar, QFileDialog, QDialog, QDialogButtonBox,
    QFormLayout, QLineEdit, QMessageBox, QTreeWidget, QTreeWidgetItem)

from .core.db import Database
from .core.importers import parse_mobaxterm, deduplicate, MobaSession
from .core.monitoring import MonitoringService, TopologyService
from .core.services import SessionUser
from .ui.module_pages import AlertsPage, ReportsPage, AuditPage, UsersPage, BackupPage, ExchangePage, SimpleDataPage

NAV = [
    ("Dashboard", "Dashboard"), ("Network Inventory", "Inventory"), ("Groups & Devices", "Groups & Devices"),
    ("Network Monitoring", "Monitoring"), ("IPAM", "IPAM"), ("VLAN Management", "VLAN Management"),
    ("Network Topology", "Topology"), ("SNMP Monitoring", "SNMP Monitoring"), ("Interactive SSH Terminal", "SSH Terminal"),
    ("Alerts & Incidents", "Alerts & Incidents"), ("Historical Metrics", "Historical Metrics"), ("Reports", "Reports"),
    ("User Management & RBAC", "Users & RBAC"), ("Configuration History", "Configuration History"),
    ("Backup & Restore", "Backup & Restore"), ("Data Import & Export", "Data Import & Export"), ("Audit Logs", "Audit Logs"), ("License Management", "License Management"),
    ("System Settings", "System Settings"),
]
STYLE = """
QMainWindow, QWidget { background: #081525; color: #e7f5ff; font-family: Segoe UI; }
QLabel#brand { color: #55d8e8; font-size: 22px; font-weight: 700; }
QLabel#edition { color: #8198ad; font-size: 11px; letter-spacing: 2px; }
QListWidget { background: #0c2034; border: 0; padding: 10px; outline: 0; }
QListWidget::item { padding: 12px 10px; color: #a9bed0; border-radius: 7px; }
QListWidget::item:selected { background: #12445c; color: #68e5f1; }
QTableWidget { background: #0c1d2d; border: 1px solid #1e3d51; gridline-color: #173247; }
QHeaderView::section { background: #10314a; color: #b9d9e7; padding: 8px; border: 0; }
QPushButton { background: #087f93; color: white; border: 0; padding: 9px 14px; border-radius: 5px; }
QPushButton:hover { background: #0aa6bb; }
QLineEdit { background: #0c1d2d; color: #e7f5ff; border: 1px solid #1e3d51; padding: 8px; }
"""

class ImportPreviewDialog(QDialog):
    def __init__(self, sessions: list[MobaSession], parent=None):
        super().__init__(parent); self.sessions = sessions; self.accepted_sessions = sessions
        self.setWindowTitle("MobaXterm Import Preview"); self.resize(920, 560)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Preview only — {len(sessions)} endpoint records. Credentials are never imported."))
        self.table = QTableWidget(min(100, len(sessions)), 5)
        self.table.setHorizontalHeaderLabels(["Group", "Session", "Host", "Port", "Protocol"])
        for i, s in enumerate(sessions[:100]):
            for j, value in enumerate([s.group, s.name, s.host, str(s.port), s.protocol]): self.table.setItem(i, j, QTableWidgetItem(value))
        self.table.horizontalHeader().setStretchLastSection(True); layout.addWidget(self.table)
        self.site = QLineEdit(); self.site.setPlaceholderText("Optional site name applied to all imported records")
        form = QFormLayout(); form.addRow("Site mapping", self.site); layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.Ok)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)

class Page(QWidget):
    def __init__(self, title: str, db: Database, parent_window=None):
        super().__init__(); self.db = db; self.parent_window = parent_window
        layout = QVBoxLayout(self); layout.setContentsMargins(28, 24, 28, 24)
        heading = QLabel(title); heading.setStyleSheet("font-size: 26px; font-weight: 700; color: #eafcff;"); layout.addWidget(heading)
        subtitle = QLabel("Central ENM data service • no production data seeded"); subtitle.setStyleSheet("color:#7896aa; margin-bottom: 18px;"); layout.addWidget(subtitle)
        if title == "Dashboard": self.dashboard(layout)
        elif title == "Inventory": self.inventory(layout)
        elif title == "Topology": self.topology(layout)
        elif title == "Monitoring": self.monitoring(layout)
        elif title == "Alerts & Incidents": self.replace_with(AlertsPage(db))
        elif title == "Reports": self.replace_with(ReportsPage(db))
        elif title == "Users & RBAC": self.replace_with(UsersPage(db))
        elif title == "Audit Logs": self.replace_with(AuditPage(db))
        elif title == "Backup & Restore": self.replace_with(BackupPage(db))
        elif title == "IPAM": self.replace_with(SimpleDataPage("IPAM", db, "SELECT address,prefix,state,note FROM ipam_records ORDER BY address", ["Address","Prefix","State","Note"]))
        elif title == "VLAN Management": self.replace_with(SimpleDataPage("VLAN Management", db, "SELECT vlan_id,name,description FROM vlans ORDER BY vlan_id", ["VLAN","Name","Description"]))
        elif title == "Configuration History": self.replace_with(SimpleDataPage("Configuration History", db, "SELECT device_id,revision,description,created_at FROM configuration_revisions ORDER BY created_at DESC", ["Device","Revision","Description","Created"]))
        elif title == "Data Import & Export": self.replace_with(ExchangePage(db))
        else:
            info = QLabel("This module is connected to the central architecture and is scheduled for its full workflow implementation."); info.setWordWrap(True); info.setStyleSheet("color:#9db7c8; font-size:14px; padding:20px;"); layout.addWidget(info); layout.addStretch()
    def replace_with(self, widget):
        old = self.layout();
        while old.count():
            item=old.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        old.addWidget(widget)
    def dashboard(self, layout):
        devices = self.db.fetch_one("SELECT COUNT(*) AS n FROM devices")["n"]; alerts = self.db.fetch_one("SELECT COUNT(*) AS n FROM alerts WHERE state='open'")["n"]; sites = self.db.fetch_one("SELECT COUNT(*) AS n FROM locations WHERE kind='site'")["n"]
        row = QHBoxLayout()
        for label, value, color in [("Managed Devices", devices, "#49d7e8"), ("Open Incidents", alerts, "#ffba66"), ("Sites", sites, "#85a8ff")]:
            card = QLabel(f"{label}\n{value}"); card.setStyleSheet(f"background:#102a40; color:{color}; padding:22px; font-size:18px; font-weight:600; border-radius:8px;"); row.addWidget(card)
        layout.addLayout(row); layout.addSpacing(24); note = QLabel("Petroleum Blue Edition\nReady for controlled inventory onboarding. Use Network Inventory to import a sanitized MobaXterm session tree."); note.setStyleSheet("color:#9db7c8; font-size:15px;"); layout.addWidget(note); layout.addStretch()
    def inventory(self, layout):
        controls = QHBoxLayout(); import_button = QPushButton("Import MobaXterm tree"); refresh = QPushButton("Refresh"); controls.addWidget(import_button); controls.addWidget(refresh); controls.addStretch(); layout.addLayout(controls)
        self.table = QTableWidget(0, 7); self.table.setHorizontalHeaderLabels(["Name", "IP Address", "Serial", "Vendor", "Model", "Type", "Status"]); self.table.horizontalHeader().setStretchLastSection(True); layout.addWidget(self.table)
        import_button.clicked.connect(self.import_mobaxterm); refresh.clicked.connect(self.load); self.load()
    def topology(self, layout):
        refresh = QPushButton("Refresh physical hierarchy"); layout.addWidget(refresh)
        self.tree = QTreeWidget(); self.tree.setHeaderLabels(["Hierarchy / Device", "IP", "Status"]); self.tree.setColumnWidth(0, 360); layout.addWidget(self.tree)
        def add_node(parent, node):
            item = QTreeWidgetItem(parent, [str(node.get("name", "")), str(node.get("ip_address") or "—"), str(node.get("status") or "—")])
            for child in node.get("children", []): add_node(item, child)
        def load_tree():
            self.tree.clear()
            for node in TopologyService(self.db).physical_tree(): add_node(self.tree, node)
            self.tree.expandToDepth(1)
        refresh.clicked.connect(load_tree); load_tree()
    def monitoring(self, layout):
        controls = QHBoxLayout(); ping = QPushButton("Ping selected device"); refresh = QPushButton("Refresh"); controls.addWidget(ping); controls.addWidget(refresh); controls.addStretch(); layout.addLayout(controls)
        table = QTableWidget(0, 5); table.setHorizontalHeaderLabels(["Name", "IP", "Type", "Status", "Last metric"]); table.horizontalHeader().setStretchLastSection(True); layout.addWidget(table)
        def load():
            rows = self.db.fetch_all("SELECT d.id,d.name,d.ip_address,d.device_type,d.status,(SELECT value FROM metrics m WHERE m.device_id=d.id ORDER BY m.id DESC LIMIT 1) last_metric FROM devices d ORDER BY d.name")
            table.setRowCount(len(rows))
            for i, row in enumerate(rows):
                for j, key in enumerate(["name","ip_address","device_type","status","last_metric"]): table.setItem(i,j,QTableWidgetItem(str(row.get(key) or "—")))
        def run_ping():
            row = table.currentRow()
            if row < 0: QMessageBox.information(self, "Monitoring", "Select a device first."); return
            name = table.item(row, 0).text(); ip = table.item(row, 1).text(); record = self.db.fetch_one("SELECT id FROM devices WHERE name=?", (name,))
            if not record or ip == "—": return
            result = MonitoringService(self.db).record_ping(SessionUser(0, "local-operator", "network_engineer"), record["id"], ip); load(); QMessageBox.information(self, "Ping result", "Reachable" if result.reachable else (result.error or "Unreachable"))
        ping.clicked.connect(run_ping); refresh.clicked.connect(load); load()
    def load(self):
        rows = self.db.fetch_all("SELECT name,ip_address,serial_number,vendor,model,device_type,status FROM devices ORDER BY name")
        self.table.setRowCount(len(rows))
        for i, row in enumerate(rows):
            for j, key in enumerate(["name","ip_address","serial_number","vendor","model","device_type","status"]): self.table.setItem(i, j, QTableWidgetItem(str(row.get(key) or "—")))
    def import_mobaxterm(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select MobaXterm sessions", str(Path.home()), "MobaXterm sessions (*.mxtsessions);;All files (*)")
        if not path: return
        sessions = deduplicate(parse_mobaxterm(path))
        if not sessions: QMessageBox.warning(self, "Import", "No supported IP endpoint sessions were found."); return
        dialog = ImportPreviewDialog(sessions, self)
        if dialog.exec() != QDialog.DialogCode.Accepted: return
        site_name = dialog.site.text().strip()
        try:
            with self.db.transaction() as conn:
                location_id = None
                if site_name:
                    row = conn.execute("SELECT id FROM locations WHERE kind='site' AND name=?", (site_name,)).fetchone()
                    location_id = row[0] if row else conn.execute("INSERT INTO locations(kind,name) VALUES('site',?)", (site_name,)).lastrowid
                inserted = 0
                for s in sessions:
                    exists = conn.execute("SELECT 1 FROM devices WHERE name=?", (s.name,)).fetchone()
                    if exists: continue
                    conn.execute("INSERT INTO devices(location_id,name,hostname,ip_address,device_type,status) VALUES(?,?,?,?,?,?)", (location_id, s.name, s.name, s.host, "network_device", "unknown")); inserted += 1
            self.load(); QMessageBox.information(self, "Import complete", f"Inserted {inserted} device records. Existing names were skipped. Credentials were not imported.")
        except Exception as exc: QMessageBox.critical(self, "Import failed", str(exc))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Enterprise Network Manager — Petroleum Blue Edition"); self.resize(1400, 860); self.setStyleSheet(STYLE); self.db = Database()
        root = QWidget(); self.setCentralWidget(root); outer = QHBoxLayout(root); outer.setContentsMargins(0,0,0,0)
        side = QVBoxLayout(); brand = QLabel("ENM"); brand.setObjectName("brand"); edition = QLabel("PETROLEUM BLUE EDITION"); edition.setObjectName("edition"); side.addWidget(brand); side.addWidget(edition)
        self.nav = QListWidget(); self.nav.addItems([x[0] for x in NAV]); side.addWidget(self.nav); sidebar = QWidget(); sidebar.setLayout(side); sidebar.setFixedWidth(260); outer.addWidget(sidebar)
        self.stack = QStackedWidget(); outer.addWidget(self.stack)
        for _, title in NAV: self.stack.addWidget(Page(title, self.db, self))
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex); self.nav.setCurrentRow(0); self.setStatusBar(QStatusBar()); self.statusBar().showMessage("Offline-first • %LOCALAPPDATA%\\ENM\\enm.db")

def main():
    app = QApplication(sys.argv); app.setStyle("Fusion"); window = MainWindow(); window.show(); sys.exit(app.exec())
if __name__ == "__main__": main()
