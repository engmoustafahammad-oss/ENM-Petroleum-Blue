"""ENM application entry point compatible with Python and PyInstaller."""
try:
    # Normal package execution: python -m enm
    from .app import main
except ImportError:
    # PyInstaller executes the bundled entry script as __main__.
    from enm.app import main

if __name__ == "__main__":
    main()
