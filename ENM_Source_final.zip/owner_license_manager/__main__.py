from __future__ import annotations

import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel, QPushButton, QFileDialog, QLineEdit, QFormLayout, QMessageBox
from enm.core.licensing import create_keypair, issue_license

class LicenseManager(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("ENM Owner License Manager"); self.resize(640,420)
        root=QWidget(); self.setCentralWidget(root); layout=QVBoxLayout(root); layout.addWidget(QLabel("ENM Owner License Manager\nOnly the authorized owner may issue signed .enml licenses."))
        form=QFormLayout(); self.customer=QLineEdit(); self.engineer=QLineEdit(); self.duration=QLineEdit("1 Year"); form.addRow("Customer",self.customer); form.addRow("Engineer",self.engineer); form.addRow("Duration",self.duration); layout.addLayout(form)
        btn=QPushButton("Create / Load Owner Key and Issue License"); btn.clicked.connect(self.issue); layout.addWidget(btn); layout.addStretch()
    def issue(self):
        directory=Path.home()/"ENM"/"owner_keys"; private=directory/"owner_ed25519_private.pem"
        if not private.exists(): create_keypair(directory)
        path,_=QFileDialog.getSaveFileName(self,"Save ENM License",str(Path.home()/"license.enml"),"ENM License (*.enml)")
        if not path: return
        Path(path).write_bytes(issue_license(private,self.customer.text().strip(),self.engineer.text().strip(),self.duration.text().strip()))
        QMessageBox.information(self,"License issued",f"Signed license saved to:\n{path}")

def main():
    app=QApplication(sys.argv); w=LicenseManager(); w.show(); sys.exit(app.exec())

if __name__ == "__main__": main()
