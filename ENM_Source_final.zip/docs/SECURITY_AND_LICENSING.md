# ENM Security and Licensing

## Credential protection

Credentials are represented as encrypted payloads using AES-256-GCM. Production Windows builds must generate a random master key and protect the key with Windows DPAPI scoped to the ENM installation/user policy. Secrets must never be written to audit metadata, logs, reports, or exception messages.

## Database

The target production database is `%LOCALAPPDATA%\\ENM\\enm.db`. SQLCipher must be included and verified in the Windows release build. The current baseline schema is compatible with SQLite and is intentionally marked PARTIAL until SQLCipher is enforced and the resulting file is checked for encrypted headers.

## Offline licensing

1. Main ENM generates an activation request containing a stable fingerprint and Windows user SID.
2. Owner License Manager, held by Mostafa Hammad, imports the request.
3. Owner License Manager signs the license payload with Ed25519.
4. The `.enml` file is transferred offline and imported by ENM.
5. ENM verifies the signature, expiry, hardware binding, and SID binding.

The private key must never ship with ENM. Production owner key storage must use DPAPI plus an owner-controlled secret. Offline clock enforcement has unavoidable limitations and must be documented to the customer.

## Network safety

SSH command assistant must classify commands as read-only, configuration-changing, or potentially destructive. Selecting autocomplete must only insert text; it must never execute a command automatically.
