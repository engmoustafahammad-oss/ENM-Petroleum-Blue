# ENM Data Import Policy

The release application is delivered with an empty production database. No MobaXterm sessions, Khalda Petroleum device records, IP addresses, topology, credentials, or customer data are embedded in the release database.

MobaXterm is an optional input format available from the application. The engineer selects a file through the import workflow, reviews a preview, resolves duplicates and site mappings, and confirms the transaction. The importer transfers endpoint metadata only; credentials are managed separately through ENM Secure Credential Vault.

The application also supports exporting device data and reports in supported formats. Export and import actions are permission-controlled and audited.
