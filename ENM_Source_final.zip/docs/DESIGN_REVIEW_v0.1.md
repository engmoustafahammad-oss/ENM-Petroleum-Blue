# ENM Design Review — v0.1

## Proposed direction

**Petroleum Control Room**: a dark navy operations workspace with petroleum-blue surfaces, cyan telemetry accents, and a cinematic but restrained header. The header uses a Western Desert facility silhouette plus a digital globe/network motif; the navigation stays compact so engineers can spend most of the viewport on tables, topology, and alerts.

## UI principles

- Dense enough for network engineers, but with clear spacing and predictable hierarchy.
- One authoritative device identity across Inventory, Monitoring, SNMP, Topology, Alerts, Metrics, IPAM, VLAN, Reports, and Configuration History.
- Status colors are consistent: cyan/blue for healthy or informational, amber for warning, red for critical, slate for unknown.
- Dark mode is primary; light mode will share the same tokens and contrast rules.
- No production network data is hard-coded into the UI.

## MobaXterm import decision

The supplied `.mxtsessions` file is treated as a source for folder/group names and endpoint metadata only. Credentials are never imported from it. The import workflow will be:

1. Select file.
2. Parse and show group/device preview.
3. Detect duplicate names/endpoints and IP conflicts.
4. Let the owner map folders to Site / Building / Room / Rack / Group.
5. Create device records in one transaction.
6. Ask the engineer to assign or test credentials separately through ENM Secure Credential Vault.

## Initial source analysis

- 398 session entries detected.
- 32 folder groups detected.
- 379 unique endpoint addresses detected.
- No explicit password field detected in the supplied text.

## Approval gate

The attached concept images are visual direction only. After approval, the UI implementation will lock the header composition, logo geometry, icon treatment, typography, spacing, and status color tokens before expanding module screens.
