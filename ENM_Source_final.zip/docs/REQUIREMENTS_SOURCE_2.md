# Requirements Source 2 — ENM

The attached `pasted_content_2.txt` was reviewed in full. It confirms the original ENM master specification and acceptance criteria.

## Confirmed interpretation

- ENM is a standalone, offline-first Windows desktop product.
- The initial production database must be empty.
- The supplied MobaXterm file is not production data embedded in the release. It is an optional import source selected by the engineer later.
- Every one of the 18 modules must have real UI, logic, persistence, validation, permissions, error handling, audit coverage, and integration.
- A placeholder page, button, source file, report, or successful build is not evidence of completion.
- SQLCipher, Windows DPAPI, AES-256-GCM, Ed25519 licensing, encrypted backups, RBAC, localization, import/export, Windows installers, and real installation validation are acceptance requirements.
- Network-device tests must be marked NOT TESTED unless they actually run against an approved lab network.
- Windows installer and shortcut tests must be marked NOT TESTED unless they actually run in a Windows environment.
- Final delivery is one organized release package, not intermediate handoffs.

The active project records and implementation status remain the operational source of truth; this file preserves the user's second requirements attachment for audit traceability.
